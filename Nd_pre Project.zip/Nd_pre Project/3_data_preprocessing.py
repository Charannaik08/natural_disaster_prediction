import numpy as np
import pandas as pd
import matplotlib.pyplot as plt #For Bar Plot for "Frequency of Disaster Types by Continent"
import seaborn as sns
from sklearn.impute import SimpleImputer # for data preprocessing to hnadle the missng values
from sklearn.preprocessing import LabelEncoder, MinMaxScaler, StandardScaler

data = pd.read_csv('natural_disasters_dataset.csv')

# Checking for Missing values
print("Null values:")
print(data.isnull().sum())


#handling missing values
data.replace('nan', np.nan, inplace=True)

'''Imputing the Missing Numerical values with Mean and Categorical values with Mode'''
numerical_cols = data.select_dtypes(include=np.number).columns
imputer = SimpleImputer(strategy='mean')
data[numerical_cols] = imputer.fit_transform(data[numerical_cols])

categorical_cols = data.select_dtypes(include='object').columns
imputer = SimpleImputer(strategy='most_frequent')
data[categorical_cols] = imputer.fit_transform(data[categorical_cols])

print(data.isnull().sum())

# Label encoding for categorical variables
label_encoder = LabelEncoder()
for col in categorical_cols:
    data[col] = label_encoder.fit_transform(data[col])
    

# Identify and remove single-valued columns
non_single_valued_columns = data.columns[data.nunique() > 1]
filtered_data = data[non_single_valued_columns]

# Visualizing correlation HeatMap for Numerical features
plt.figure(figsize=(16, 10))
correlation_matrix = filtered_data.corr()
sns.heatmap(correlation_matrix, annot= False, cmap='magma')

# Setting Title for the plot
plt.title('Correlation Heatmap')
plt.show()




