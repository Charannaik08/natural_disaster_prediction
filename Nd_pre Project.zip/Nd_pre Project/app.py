from flask import Flask, render_template, request, redirect, url_for, session,flash
from werkzeug.security import generate_password_hash, check_password_hash
import mysql.connector
import joblib
import numpy as np
import requests

app = Flask(__name__)
app.secret_key = 'charan0812'  # Secret key for session management

# Configure MySQL connection
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="mysql",
    database="disaster_app"
)

# Load the pre-trained model and scaler
model = joblib.load('random_forest_model.joblib')
scaler = joblib.load('scaler.joblib')

# Mapping of numeric labels to disaster names
disaster_mapping = {
    0: 'Drought',
    1: 'Earthquake',
    2: 'Epidemic',
    3: 'Extreme temperature',
    4: 'Flood',
    5: 'Fog',
    7:'Impact',
    8: 'Insect infestation',
    9: 'Landslide',
    10: 'Mass movement (dry)',
    11: 'Storm',
    12: 'Flood',
    13: 'Wildfire',
}

# Reverse geocoding function to get location from lat/lon
def get_location_from_lat_lon(latitude, longitude):
    url = f"https://nominatim.openstreetmap.org/reverse?lat={latitude}&lon={longitude}&format=json"
    response = requests.get(url, headers={'User-Agent': 'Flask App'})
    
    if response.status_code == 200:
        data = response.json()
        country = data.get('address', {}).get('country', 'Unknown Country')
        city = data.get('address', {}).get('city', '')
        return f"{city}, {country}" if city else country
    else:
        return 'Unknown Country'

# User registration route
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']

        # Hash the password using pbkdf2:sha256
        hashed_password = generate_password_hash(password, method='pbkdf2:sha256', salt_length=8)

        cursor = db.cursor()
        try:
            # Insert user into the database
            cursor.execute(
                "INSERT INTO users (username, email, password) VALUES (%s, %s, %s)", 
                (username, email, hashed_password)
            )
            db.commit()
            flash('Registration successful! You can now log in.', 'success')
            return redirect(url_for('register'))
        except mysql.connector.Error as err:
            print(f"Error: {err}")
            db.rollback()
            flash('Registration failed. Please try again.', 'danger')

    return render_template('register.html')


# User login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        cursor = db.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
        user = cursor.fetchone()

        if user and check_password_hash(user['password'], password):
            session['user_id'] = user['id']
            session['username'] = user['username']
            return redirect(url_for('index'))
        else:
            flash('Invalid username or password.', 'danger')

    return render_template('login.html')

# User logout route
@app.route('/logout', methods=['POST'])
def logout():
    session.clear()
    return redirect(url_for('login'))

# Home page
@app.route('/')
def index():
    if 'username' in session:
        return render_template('index.html')
    else:
        return redirect(url_for('login'))

# Prediction route
@app.route('/predict', methods=['POST'])
def predict():
    # Get form data
    year = request.form['Year']
    dis_mag_scale = request.form['Dis_Mag_Scale']
    dis_mag_value = request.form['Dis_Mag_Value']
    country = request.form['Country']
    longitude = request.form['Longitude']
    latitude = request.form['Latitude']

    # Prepare features for model prediction
    features = np.array([[year, dis_mag_scale, dis_mag_value, country, longitude, latitude]])
    features_scaled = scaler.transform(features)

    # Predict disaster type
    prediction_numeric = model.predict(features_scaled)[0]
    prediction_name = disaster_mapping.get(prediction_numeric, "Unknown Disaster")

    # Reverse geocode to get country from latitude and longitude
    country_from_lat_lon = get_location_from_lat_lon(latitude, longitude)

    # Render result page
    return render_template('result.html', 
                           prediction=prediction_name, 
                           latitude=latitude, 
                           longitude=longitude, 
                           country=country_from_lat_lon)

if __name__ == '__main__':
    app.run(debug=True)
