'''Data collection using Dataset -natural_disasters_dataset'''

import numpy as np
import pandas as pd

# Loading the dataset
data = pd.read_csv('natural_disasters_dataset.csv')

# Displaying information about the Dataset
print(data.info())

#print first 10 values
print(data.head(10))
print(data.tail(20))