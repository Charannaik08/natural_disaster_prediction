import numpy as np
import pandas as pd
import matplotlib.pyplot as plt #For Bar Plot for "Frequency of Disaster Types by Continent"
import seaborn as sns
from sklearn.impute import SimpleImputer # for data preprocessing to hnadle the missng values
from sklearn.preprocessing import LabelEncoder, MinMaxScaler, StandardScaler
from sklearn.feature_selection import mutual_info_classif

data = pd.read_csv('natural_disasters_dataset.csv')



X = data.drop('Disaster Type', axis=1)  
y = data['Disaster Type']

# Based on Domain Knowledge we are including 'Year' feature
X['Year'] = X['Year'].astype(float)  
mutual_info = mutual_info_classif(X, y)
feature_importance = pd.Series(mutual_info, index=X.columns)

# Selecting top 10 features
selected_features = feature_importance.nlargest(10).index  

if 'Year' not in selected_features:
    selected_features = selected_features.append(pd.Index(['Year']))

# Printing the selected features
X_selected = X[selected_features]
print(X_selected.columns)

# Loading the selected features into a new CSV file
selected_features = [
    'Year',  'Dis Mag Scale','Dis Mag Value', 'Country', 'Longitude', 'Latitude', 'Disaster Type'
]

data_selected = data[selected_features]
# Save the new CSV file as preprocessed_data.csv
data_selected.to_csv('preprocessed_data.csv', index=False)

data_selected = pd.read_csv('preprocessed_data.csv')
data_selected.head(10)
